# Deploy BlueZone on Render

The supplied chat logs show two related problems: `app` was missing from the uploaded repository, and `main:app` launched code that uses package-relative imports. Keep the package intact. Do not remove dots from Python imports.

## Upload the correct layout

Extract BlueZone-Render.zip. Upload the extracted contents to your GitHub repository, preserving the `app` folder. Do not upload the ZIP itself or flatten that folder. The repository root must contain:

```text
app/
  __init__.py
  main.py
  db.py
  ...
  static/
requirements.txt
render-start.sh
render.yaml
```

Do not upload `.env`, `.venv`, database files, or local accounts. The archive excludes these. Review existing repository changes before replacing files; old root-level Python copies are not used by the package startup command.

## Fix your existing Render service

In Blue-zone-v2, Settings:

| Setting | Value |
| --- | --- |
| Runtime | Python 3 |
| Branch | main |
| Root Directory | Leave empty |
| Build Command | `pip install -r requirements.txt` |
| Start Command | `sh render-start.sh` |
| Health Check Path | `/api/health` |

In Environment, set `PYTHON_VERSION=3.14.7`, `BLUEZONE_ENV=production`, and `BLUEZONE_MAX_USERS=100`. Remove a previously configured localhost `BLUEZONE_ORIGIN`; BlueZone now uses Render's own HTTPS URL automatically. Remove the unnecessary `PYTHONPATH` override from the previous advice. For a custom domain, set `BLUEZONE_ORIGIN` to its exact HTTPS origin without a path; use that domain for login.

Commit the corrected files, then deploy the latest commit. If the service's auto-deploy is enabled, the commit may already trigger deployment. The included blueprint is for creating a new free demonstration service; it does not automatically update an existing manually created service.

## Storage: choose before inviting learners

The free service is a demonstration. SQLite data, including accounts, progress and admin changes, can disappear after a restart, redeploy or spin-down. Never promise persistent progress on this configuration.

For the current SQLite architecture, select a paid web service and attach a persistent disk mounted at `/var/data`, then set `BLUEZONE_DB=/var/data/bluezone.db`. Keep one service instance and one worker. Confirm Render's current cost before purchasing. Back up the database regularly using `python -m app.backup` (see README). Adding a disk does not migrate data from a previous ephemeral instance. For a free service with durable external storage, a PostgreSQL migration and external database configuration remain separate work.

## Verify after deployment

1. Open the HTTPS URL shown in Render. The premium landing page should appear.
2. Open `/api/health`; expect `{"status":"ok","version":"1.0.0"}`.
3. Open `/app?mode=register`, register a test learner, sign out and sign back in.
4. Complete a beginner mission and confirm progress persists after signing back in.
5. For persistent hosting, repeat the check after a redeploy.

Create an administrator using Render's service shell on a plan that provides shell access:

```sh
python -m app.manage create-admin --email YOUR_EMAIL --name "Administrator"
```

Enter the password at the private prompt. Then sign in and open `/app#admin`. There is no public admin bootstrap or default password. The free service does not provide this shell, so full admin provisioning needs a suitable hosting plan or a separately designed secure provisioning flow.

The built-in tutor works without an API key. Optional live AI requires `OPENAI_API_KEY` and `OPENAI_MODEL` as private Render environment variables. Do not commit keys.

## References

- https://render.com/docs/deploy-fastapi
- https://render.com/docs/environment-variables
- https://render.com/docs/free
- https://render.com/docs/disks

Deployment status: configuration prepared locally. A live deployment must be verified in the signed-in Render account; preparation alone does not publish the site.
