#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-10000}" --workers 1
