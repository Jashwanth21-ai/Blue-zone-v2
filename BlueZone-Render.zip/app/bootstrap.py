"""Optional first administrator from private host environment settings."""
import os
import time
from .db import connect, audit
from .models import Register
from .security import hasher

def provision_admin():
    email=os.environ.get('BLUEZONE_ADMIN_EMAIL','').strip()
    password=os.environ.get('BLUEZONE_ADMIN_PASSWORD','')
    if not email and not password:
        return
    # Never print validation errors: they can include the supplied password.
    try:
        account=Register(email=email,password=password,name='Administrator')
    except Exception:
        raise RuntimeError('Administrator setup requires a valid email and a 12–128 character password in the private host environment.') from None
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
            return
        if db.execute('SELECT 1 FROM users WHERE email=?',(account.email,)).fetchone():
            raise RuntimeError('Administrator setup email belongs to an existing account. Use a different email or the local administration command.')
        row=db.execute("INSERT INTO users(email,name,password,role,created) VALUES(?,?,?,'admin',?)",(account.email,account.name,hasher.hash(account.password),int(time.time())))
        audit(db,row.lastrowid,'host.admin_created',row.lastrowid)
